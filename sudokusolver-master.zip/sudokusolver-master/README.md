# sudokusolver

- Add a valid sudoku that has 0 in place of empty spaces
- Click on submit
- Click on solve

Sudoku will be solved using recursion with backtracking!

Note: After clicking on solve, the user sees some lag. This lag is intentional so that the user can see how the problem is being solved. The actual runtime is far less.
